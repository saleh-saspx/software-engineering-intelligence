# Unified engineering knowledge model

How the skill's knowledge fits together, how findings are classified, how conflicts between
rules are resolved, and which contradictions between the source books have been settled.
Read sections 4–6 whenever two pieces of guidance pull in different directions.

## Contents
1. Layers of the model
2. How the concerns reinforce each other
3. Quality attributes
4. Taxonomy: rule levels, finding types, severity, confidence
5. Context gates — what to establish before applying any rule
6. Conflict resolution
7. Resolved tensions between sources (T-01 – T-34)
8. Exceptions and waivers
9. Explaining a recommendation

## 1. Layers of the model

```
Principles (principles.md, P-xx)        why — sourced, with intent and limits
   └─ Rules (rules/*.md, DOMAIN-AREA-NN) what — normative, levelled, with signals and fixes
        └─ Checks                        how to detect — signals, scripts, tools, questions
             └─ Workflows (workflows/)   when and in what order — per task type
                  └─ Outputs (assets/templates/) findings, reports, TD items, ADRs, plans
```

- A **principle** explains a force (e.g. "dependencies point toward policy").
- A **rule** turns it into a checkable expectation with a level, default severity, signals,
  remediation, verification and exceptions.
- A **check** is how a rule is detected: a code signal, a script (`scripts/`), an external tool,
  or a question to ask the user.
- A **workflow** sequences checks for a task (review, assessment, refactoring…).
- An **output** records results in a form people can act on.

Navigation: `rules/index.md` lists every rule ID with its title and level, so you can pick the
handful relevant to a task without loading whole catalog files.

## 2. How the concerns reinforce each other

| Concern | Main question | Sources | Reinforces / constrains |
|---|---|---|---|
| Clean Code | Can a reader understand and safely change this unit? | S1 | Makes testing and review cheaper; local smells are inputs to TD analysis |
| SOLID / design | Does each module change for one reason, and do dependencies point the right way? | S2 Ch.7–11, S1 Ch.10 | Bridges code to architecture; DIP enables testability |
| Components and architecture | Are boundaries where change and actors differ, with acyclic, stability-respecting dependencies? | S2 | Determines blast radius of change; ADRs record it |
| Domain modelling (DDD) | Does the model reflect the business language and boundaries? | X1 (extension) | Supplies *where* boundaries go when the domain is complex |
| Testing | Is behaviour pinned so change is safe? | S1 Ch.9, S2 Ch.28, X5 | Precondition for refactoring; security tests verify controls |
| Refactoring | Can structure improve without behaviour change? | S1 Ch.14/16, X3, X4 | The repayment mechanism for TD |
| Technical debt | Which structural weaknesses actually cost us, and is fixing them worth it? | S3 | Prioritises everything above against business value |
| Security | Can an adversary make it do what it shouldn't? | S5, S6 | Overrides style and design preferences; adds mandatory rules |
| Reliability / performance | Does it keep working, fast enough, under real conditions? | S1 Ch.13, X6, X12 | May justify deviations from "clean" structure, with evidence |
| Analysis limits | How much do our checks actually prove? | S7 | Governs every claim the skill makes |
| Decisions (ADR) | Why is it like this, and is that still valid? | S4 | Turns trade-offs into constraints; prevents re-litigation |
| Quality attributes and architecture description | Which measurable qualities drive the structure, and is it described and reviewed against them? | S8 Ch.6–7, §9.1, §3.1.3 | Supplies the forces ARCH rules need; turns NFRs into tests |
| Extensibility and evolution | Where must the system vary, and can it change without breaking what plugs into it? | S8 §7.6, Ch.15; S2 Ch.17; X15, X16 | Shapes OCP and contracts; DES-SIMP is its counterweight |
| Data management | Do data and schema stay correct, recoverable and evolvable under concurrency, growth and deploys? | S8 §7.2.1, §14.1.6, §14.3; X19, X20 (largely extension) | Overlaps reliability and security; migrations are deployments |
| Verification and validation | Do we build the product right — and the right product — and how much do our checks prove? | S8 Ch.3, Ch.9, Ch.10, Ch.12; S7 | Generalises testing; feeds the evidence discipline |
| Secure design and supply chain | Is security designed in, and is every dependency and build step trusted deliberately? | S8 Ch.3, Ch.11, §14.6; S5, S6 | Comes before code-level security review |
| Scalability | Does capacity grow with resources, and is shared capacity protected? | S8 §14.1.2; X17 Ch.11; X6 | Pairs with performance; claims need measurement |

The concerns form one method: **understand context → protect behaviour (tests) → find what
impedes change or creates risk → classify and prioritise it → change in small verified steps →
record decisions**. No concern is applied in isolation; a "clean" refactor that breaks an
authorisation check or ignores an ADR is a failure.

## 3. Quality attributes

Findings map to the attributes they affect. The quality evaluation (`quality-model.md`) rates
these dimensions separately — never as a single score. ISO/IEC 25010:2023 (cited in S8 §12.2.1)
names nine product-quality characteristics; the seven dimensions below group them for code review
and add testing and data, which reviewers rate separately.

| Dimension | Sub-attributes | Rule domains |
|---|---|---|
| Code quality | readability, naming, function/class design, complexity, duplication, error handling | CODE, DES |
| Architecture | boundaries, dependency direction, modularity, domain isolation, consistency, fit-for-context, quality-attribute fit, extensibility | ARCH, DES |
| Security | input handling, authN/authZ, sessions, secrets, data protection, configuration, dependencies, secure design, supply chain | SEC |
| Testing and verification | testability, test design and adequacy, oracles, reliability of tests, behavioural focus, acceptance and validation | TEST |
| Maintainability | debt load, changeability, documentation, dependency health, ownership, operability, release safety | TD, DLV, CODE-CMNT |
| Reliability, performance and scalability | failure behaviour, resources, concurrency, consistency, latency/throughput, scalability, observability | REL, PERF, API |
| Data management | integrity, modelling, migrations, transactions and isolation, recovery, replication, growth, tenancy, privacy | DATA |

## 4. Taxonomy

### 4.1 Rule levels (normative strength)

| Level | Meaning | May be overridden by |
|---|---|---|
| `mandatory` | Violations cause security, data-integrity or correctness failures, or legal exposure. | Nothing silently. A documented, compensating control can downgrade a *finding's* severity, never the rule. |
| `constraint` | An architectural or project constraint in force: an accepted ADR, a published API contract, a documented team convention, a framework's required structure. | A superseding decision (new ADR) — raise it, don't bypass it. |
| `strong` | Strong engineering recommendation; deviation needs a stated reason. | Context gates (section 5), measured performance needs, ecosystem idioms. |
| `contextual` | Applies only when its stated conditions hold. | Absence of the conditions. |
| `optional` | Improvement worth suggesting; never blocks. | Anything. |

### 4.2 Finding types (classify *before* judging severity)

| Type | Definition | Default handling |
|---|---|---|
| `defect` | Behaviour is wrong now (or wrong for reachable inputs). | Fix; severity by impact. Not TD (S3 Ch.1). |
| `vulnerability` | An exploitable weakness. Sub-label: confirmed / potential. | Fix; severity by risk (likelihood × impact). |
| `reliability-risk` | Likely failure under real conditions (timeouts, races, leaks, consistency). | Fix or mitigate. |
| `performance` | Measured, or structurally evident (N+1, unbounded load), cost. | Fix if on a hot path; mark unmeasured claims. |
| `tech-debt` | Expedient structure that raises the cost of future change (S3 Ch.1). | Prioritise by interest vs. principal (`workflows/tech-debt.md`). |
| `architecture-risk` | Structural issue threatening boundaries, dependency direction or evolvability. | TD with elevated weight (S3 Principle 6). |
| `test-gap` | Missing or weak verification for risky behaviour. | Add tests proportionate to risk. |
| `trade-off` | A deliberate, still-valid compromise with known costs. | Record (ADR/TD register); don't "fix". |
| `legacy-constraint` | Imposed by an external system, contract or migration state. | Work within it; note the cost. |
| `imperfection` | Real but harmless in context (stable code, low traffic, no planned change). | Usually omit; at most a `nit`. |
| `question` | Cannot be judged without information you lack. | Ask; don't guess a severity. |

### 4.3 Severity (per finding)

| Severity | Meaning | Merge/release impact |
|---|---|---|
| `blocker` | Exploitable vulnerability, data loss/corruption, broken behaviour, secret exposure, build/test breakage, violation of a mandatory rule. | Must be resolved before merge/release. |
| `major` | Significant risk or cost: likely defect, notable maintainability or reliability hazard, constraint violation. | Resolve before merge unless explicitly accepted with a reason. |
| `minor` | Local quality issue with modest cost. | Fix now if cheap, else when next touching the code. |
| `nit` | Style or preference. | Never blocks; batch or omit. |

Severity = impact × likelihood × exposure, judged in context. A rule's `severity` field is the
default range, not a verdict.

### 4.4 Confidence (per finding)

| Label | Evidence required |
|---|---|
| `confirmed` | Observed by running code/tests, reproduced, or the full code path traced with no unresolved unknowns (inputs, config, callers). |
| `likely` | Strong static evidence; remaining unknowns are minor and stated (e.g. "assuming no global middleware sanitises this"). |
| `possible` | Pattern-level signal (tool hit, name, idiom) without tracing; requires verification. |

Security wording follows the same scale: *confirmed vulnerability* = confirmed; *potential
vulnerability* = likely/possible; *hardening recommendation* = a finding with no current
exploit path; *unverified concern* = a `question`.

## 5. Context gates

Establish these before applying rules. Skipping them is the main source of false positives.

1. **Ecosystem and data stores** — language, framework, versions, idioms (`languages/`); the
   database engines and major versions in production and in tests, the ORM and the migration tool
   (`scripts/repo_survey.py` reports what configuration shows). Record anything not established as
   UNKNOWN and name the conclusions that depend on it; never assume an engine from a framework's
   default. A rule that conflicts with an established idiom yields to the idiom unless safety is at
   stake.
2. **Local conventions** — formatter/linter configs, existing patterns, naming, error model,
   directory structure, `CONTRIBUTING`, ADRs. Consistency with the codebase beats generic taste.
3. **Lifecycle** — prototype, MVP, growth, mature, legacy-in-maintenance, scheduled-for-retirement.
   Expected lifetime and change rate set how much structure pays off (S3 Principle 9).
4. **Domain complexity** — CRUD/data-centric vs. rule-rich; regulatory or financial stakes.
5. **Team and operations** — team size and count, deployment and on-call maturity.
6. **Non-functional requirements** — stated performance, availability, security, compliance needs.
7. **Scope of the request** — what the user asked for; out-of-scope findings are reported briefly
   or not at all, never acted on silently.

When a gate cannot be established, state the assumption you are making in the output.

## 6. Conflict resolution

### 6.1 Precedence (highest first)

1. **Safety and correctness** — mandatory security rules, data integrity, legal/compliance,
   correctness of behaviour.
2. **Explicit constraints** — accepted ADRs, published API contracts, documented team rules.
   If a constraint conflicts with (1), raise it explicitly; do not silently violate either.
3. **Behaviour preservation and change risk** — don't trade a known-working system for a
   cleaner untested one; the safety net comes first.
4. **Evidenced non-functional needs** — measured performance, availability, cost constraints.
5. **Structural principles** — dependency direction, boundaries, cohesion (S2), weighted by
   context gates 3–5.
6. **Ecosystem idioms and local consistency** (P-53).
7. **Generic code-style heuristics** (S1 Ch.2–5).
8. **Personal or reviewer preference** — never a finding above `nit`.

### 6.2 Procedure when rules conflict

1. Name both rules and the force behind each (cite IDs).
2. Check context gates: does one rule's `applies`/`except` condition already settle it?
3. Apply the precedence order.
4. Prefer the option that is **reversible** and **smaller**, when the higher-precedence concern
   is satisfied either way (S2 Ch.15, Keeping Options Open).
5. State the trade-off in the output and, for architectural choices, propose an ADR.

## 7. Resolved tensions between sources

| ID | Tension | Resolution adopted |
|---|---|---|
| T-01 | S1 Ch.3 wants very small functions; locality and Go/C idioms favour longer linear code. | Criterion is single purpose and single level of abstraction; length is a signal only (CODE-FUNC-01). |
| T-02 | S1 Ch.7 "use unchecked exceptions / exceptions over return codes" vs. Go `error` values, Rust `Result`, checked exceptions in some Java codebases. | Follow the ecosystem's error model; keep the invariant "no silent failures, context added, happy path separated" (CODE-ERR-01). |
| T-03 | S1 J1 recommends wildcard imports; modern Java style guides and formatters forbid them. | Follow the project's formatter/style guide. J1 is treated as superseded convention. |
| T-04 | S1 G5 (and DRY, cited in S8 §6.2.3) calls duplication a root problem; S2 Ch.16 warns that unifying accidental duplication couples unrelated actors. | Unify only true duplication (same reason, same rate of change) (CODE-DUP-01/02). S8 §15.3 agrees: watch for code that only looks similar. |
| T-05 | S1 Ch.4 treats most comments as failures; S5 and regulated domains need documented reasoning and security rationale. | Comments for *why*, constraints, warnings and public APIs are required where non-obvious (CODE-CMNT-01). |
| T-06 | S2 Ch.30–32 treat DB/web/framework as details; framework-centric stacks (Laravel, Rails, Django, Spring Data) embed them by design; S1 Ch.6 describes Active Record as a legitimate data structure. | Isolate details in proportion to domain-rule richness and volatility. For CRUD-heavy apps, framework-native structure is correct (ARCH-FIT-01, ARCH-DET-01). |
| T-07 | Popular microservice adoption vs. S2 Ch.27 (services are a deployment mode; the Kitty Problem). | Modular monolith by default; split on concrete deployability/scaling/team needs plus operational maturity (ARCH-STYLE-01). S8 §14.1.4–14.1.5 adds cost evidence and the fleet-scale caveat for Kubernetes. |
| T-08 | S1 G23 prefers polymorphism over switch; functional and data-oriented styles use pattern matching; class explosions harm readability. | One switch per type decision is fine (S1's own "ONE SWITCH" rule); repeated switches on the same type tag call for polymorphism or a lookup (CODE-CPLX-03). |
| T-09 | S1 Ch.9 "one assert per test" vs. "single concept per test" (also S1 Ch.9). | Single concept per test (TEST-UNIT-02). |
| T-10 | S1 Boy Scout Rule (always clean up) vs. S3 Principle 5 (TD ≠ bad quality) and review-cost concerns. | Clean what you touch, behaviour-preserving, separately committed, proportionate to the change (AGT-MIN-02, TD-DEC-03). S8 §9.3 and §15.4 take the same position: small related clean-ups are fine; record larger ones separately. |
| T-11 | S1 N6 avoid encodings / interface prefixes vs. .NET `IService`, C# `_field` conventions. | Ecosystem convention wins (P-53). |
| T-12 | S1 "don't return/pass null" vs. languages with nullable/optional types where `null`/`None` is idiomatic and type-checked. | Express absence through the type system (Optional, nullable types, `T | None`); flag only unchecked nulls (CODE-ERR-04). |
| T-13 | S5's cyclomatic-complexity bands (0–10 / 11–15 / 16–20) vs. their misuse as hard gates. | Use as a risk-based pointer to where to look (S5's stated purpose), not as a pass/fail rule (CODE-CPLX-01). |
| T-14 | S2's full boundaries everywhere vs. S1 Ch.12 rule 4 and S2 Ch.24–25's own YAGNI caveat. | Boundary only where a named force exists; partial boundaries as the hedge (ARCH-FIT-02). |
| T-15 | Mission-level wish to treat vulnerabilities and performance problems "as technical debt" vs. S3 Ch.1 excluding defects and external quality from TD. | Classify by finding type (4.2); TD is one type among several, prioritised with its own model. |
| T-16 | Clean Code's DI frameworks/AOP chapter (S1 Ch.11, Java proxies, AspectJ) vs. present-day ecosystems. | Keep the principle (separate construction from use, P-17); ignore the dated mechanism. |
| T-17 | S8 §10.2.4 and X5 present the testing pyramid (many unit, fewer integration, few end-to-end tests) as the default; P-38 allows an integration-heavy portfolio for thin-logic services. | The pyramid's economics are the rule — find defects low and early, keep feedback fast, avoid the ice-cream cone; the shape follows where the logic lives. Judge by feedback time and escaped defects (TEST-STRAT-02). |
| T-18 | S5's cyclomatic-complexity bands (1–10 low, 11–15 medium, 16–20 high, above 20 very high) differ from S8 §10.3.1's (1–10 simple, 11–20 moderate, 21–50 risky, above 50 decompose). | Both are heuristics: use either as a pointer for review and test effort and compare with the codebase's own distribution; never as a gate (CODE-CPLX-01, T-13). |
| T-19 | S8 §7.1.1's layered pattern has dependencies pointing down to infrastructure; S2 Ch.22's Dependency Rule points them inward to policy, with infrastructure depending on the domain. | Invert the domain → infrastructure dependency where rules are rich or infrastructure volatile (S8 §6.5.3 itself does so with an application-owned interface); in CRUD-heavy, framework-centric apps conventional downward layering is acceptable (ARCH-DEP-01, ARCH-DET-02, ARCH-FIT-01). |
| T-20 | S2 Ch.30 treats the database as a detail kept away from policy; S8 §7.2.1 has the shared store enforce integrity and concurrency control for every accessor. | Integrity constraints (keys, uniqueness, foreign keys, checks, types) belong in the database as a safety net for every writer; business policy that changes with the domain belongs in code; avoid workflows in triggers where rules are rich (DATA-SCHEMA-01, ARCH-DET-01, DATA-MODEL-02). |
| T-21 | S8 §6.2.3 ("depend on interfaces, not implementations") and X15 Item 18 (prefer interfaces) vs. S2 Ch.11 (stable concretions are fine) and DES-SIMP-03 (single-implementation interfaces without a seam are ceremony). | Interfaces at volatile boundaries, published extension points, test seams and inverted dependencies; concrete classes elsewhere (DES-DIP-01, DES-SIMP-03, ARCH-EXT-02). |
| T-22 | S8 §10.5 notes MC/DC coverage is mandated in avionics and §10.1.3 calls low coverage an alarm; TEST-COV-01 and S8 §10.1.3 and §12.1.2 (Goodhart) warn against coverage targets. | Coverage criteria mandated by a domain standard are constraints. Otherwise coverage is a floor and an alarm on risky code, never a target; strengthen the criterion only for critical decisions, and check assertion strength with mutation testing (TEST-COV-01, TEST-COV-02, TEST-MUT-01). |
| T-23 | X15 Item 17 (design and document for inheritance, or else prohibit it — final by default) vs. frameworks that need subclassable classes for proxies and mocks (Spring, Hibernate, Kotlin's all-open plugin) and Active Record base classes. | Follow the framework where it needs subclassable classes (P-53); keep library and domain classes the framework doesn't proxy final by default; never extend a class that wasn't designed for it (DES-EXT-01). |
| T-24 | Singleton: S10 and S9 Ch.19 present it as a catalog pattern for one shared instance with a global access point (listing its SRP, testing and threading costs); X15 Item 3 shows how to enforce it in Java; S1 G18, DES-DI-02 and DI practice reject global access from business code. | One instance, yes; global access, no. Let the composition root or container own a single instance and inject it (Spring singleton scope, Laravel `singleton`, a module value in Python or Go). Keep the classic pattern for process-unique resources at the edges, thread-safe and resettable in tests (DES-DI-02, `patterns/singleton.md`). |
| T-25 | Template Method: S10, S9 Ch.35 and X2 define it through inheritance; X15 Item 16, P-70 and DES-PAT-02 prefer composition; frameworks call callback-based classes "templates" (Spring `JdbcTemplate`, `RestTemplate`). | Classify by structure: a skeleton calling overridden steps is Template Method; a skeleton calling functions passed in is a callback template (Strategy-like). Prefer callbacks in new code; follow the framework where it requires subclassing (P-53). |
| T-26 | "Factory": S10's Factory Method (subclasses decide the product) and Abstract Factory (families) vs. X15 Item 1's static factory methods (named constructors) and the common "simple factory" function choosing a class. | Name precisely and judge each by its own force: static factories and simple factories are idioms, not the catalog patterns; none of them justifies a parallel hierarchy of factory classes (DES-PAT-01, DES-PAT-04). |
| T-27 | Framework and language vocabulary vs. catalog names: Laravel "Facades" (static proxies to container services), Spring singleton and prototype scopes (lifetimes), Python and TypeScript "decorators" (definition-time wrappers or annotations), Servlet filters and middleware described as decorators. | Describe the mechanism first and use a catalog name only when the participants and defining property match (DES-PAT-04): Laravel facades are Service Locator plus Proxy; scopes are lifetimes; middleware that can stop a request is a chain handler (`patterns/frameworks.md`). |
| T-28 | S9 (a Bookey summary) vs. S10 (the author's own pages): S9 garbles some relations (Builder's evolution path; Adapter's comparison with Proxy and Facade), broadens Abstract Factory's relation to Facade, suggests multiple inheritance where the book describes a multilevel hierarchy, is cut off in eight chapters, and adds commentary attributed to other authors. | S10 is authoritative for catalog content; S9 is cited only where it agrees or adds nothing contradictory; its commentary is not used; each difference is noted in the pattern file's provenance line. |
| T-29 | X2 lists 23 patterns including Interpreter; S10's catalog has 22 and S9 none beyond them. | Keep the 22 as the catalog; Interpreter is a supplementary pattern, used only for a tiny, stable grammar — otherwise prefer a parser generator, a rule table or an existing expression library (`patterns/index.md` §3). |
| T-30 | S10's Observer (in-process subscription with no guaranteed order) vs. event-driven integration across processes (X13; S8's publish–subscribe), which needs durable delivery, idempotent consumers and versioned schemas. | Treat in-process observers and integration events as different tools: framework events are neither durable nor transactional across processes; publish integration events through an outbox with idempotent consumers (REL-CONS-02, DATA-EVOL-01). |
| T-31 | S1 Ch.12 (Simple Design rule 1: runs all the tests) and DLV-BUILD-01 (one command runs all tests) vs. S8 §10.1.6 (select and prioritise a subset per change once the suite outgrows its time budget). | S8 §10.1.6 itself resolves it: run the full suite while that is practical; beyond that, select per change for the fast stages (TEST-SEL-01) and keep the full suite at a stated gate — merge queue, scheduled build or release — so selection misses are caught; a slow suite must never quietly become an unrun suite. One command still runs everything. |
| T-32 | TEST-DATA-01 and TEST-ENV-01 (test data access on the real engine and production version) vs. the fast-feedback practice of embedded or in-memory databases (X14). | Classify by engine dependence (TEST-DATA-02): DB-free tests need no database at all; tests whose assertions depend on SQL run on real engines; an embedded stand-in is at most an extra fast lane and is never reported as evidence of engine behaviour (`testing/database-matrix.md`). |
| T-33 | Random UUID keys (unguessable, generated anywhere — X14) vs. B-tree locality (X25: random inserts split pages across the index; clustered engines copy the key into every secondary index — X27 InnoDB and SQL Server documentation). | Decide per engine and need: a compact sequential or time-ordered primary key, especially on clustered tables; a separate random public identifier when enumeration matters; time-ordered UUIDs when IDs must be generated outside the database; never rely on an identifier's unguessability for access control (DATA-KEY-01, SEC-AUTHZ-02). |
| T-34 | S2 Ch.30 (the database is a detail; keep options open) and ORM portability vs. engine-specific features that fix correctness or performance (X26 partial and function-based indexes; X27 upserts, JSON operators, exclusion constraints). | Portability is a requirement, not a default. With one production engine, use its features behind the data-access layer and test on that engine; when several engines are promised, restrict to the common subset or isolate per-engine implementations and test each (DATA-PORT-01, TEST-DATA-02). Related: T-06. |

## 8. Exceptions and waivers

- A rule's `except` field lists known legitimate exceptions. Applying one requires saying so.
- A project can waive a `strong`/`contextual` rule by convention or ADR; the skill then treats the
  waiver as a `constraint` and stops reporting the rule (except to note a waiver is outdated).
- `mandatory` rules cannot be waived by convenience. If the user insists, comply only where it is
  their decision to make (e.g. accepted risk in their own system), record the accepted risk, and
  never weaken a control in a way that harms third parties.
- Inline suppression comments (`# noqa`, `@SuppressWarnings`, `// nolint`) are fine when they carry
  a reason; unexplained suppressions are a `minor` finding (S1 G4, Overridden Safeties).

## 9. Explaining a recommendation

When a recommendation about data or testing is consequential — it changes a schema, a type, a key,
an index, a transaction design, a durability setting, the choice of engine or storage engine, or what a
test plan covers — or the user asks to understand it, explain it in this order. For small decisions
compress to points 1, 2 and 6 in a sentence or two; depth is not length (SKILL.md §1). A verdict on a
technology the user proposes keeps its mechanism even when compressed: what it does, what it costs,
and when it would be the right choice (points 1, 4 and 6).

1. **Concept** — what it means, in a sentence or two.
2. **Why it matters here** — the failure or cost it prevents in this system.
3. **Alternatives** — the realistic options, including doing nothing.
4. **Trade-offs** — what each option buys and costs: correctness, performance, operability,
   portability, effort.
5. **Failure modes** — what goes wrong if the advice is ignored, or applied blindly.
6. **When it changes** — the conditions under which another option is right: scale, engine,
   workload, regulation, team.
7. **Example** — a minimal concrete one (DDL, query, test), from the user's code where possible.
8. **Engine or ecosystem differences** — what differs across the engines in use, checked against
   the manual or marked unverified (`data/engines.md`).

Label what kind of claim each point is, using the provenance and evidence vocabulary already in this
model: an **established principle** (a `direct` or `synthesized` rule, for example that a normal form
removes a named anomaly); a **context-dependent recommendation** (state the context it depends on);
**engine-specific behaviour** (engine, version, where it was checked); **expert practice** (an
`extension` rule — practice, not a sourced fact); and, for performance, **expected, estimated or
measured** (`data/performance.md` §13). No best practice is presented as unconditional: point 6 names
the condition that would reverse it.

